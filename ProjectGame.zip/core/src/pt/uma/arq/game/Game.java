package pt.uma.arq.game;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import pt.uma.arq.entities.*;

import java.awt.*;

public class Game extends ApplicationAdapter  {
    private SpriteBatch batch;
    private BackgroundManagement backgroundManagement;
    private BitmapFont font;
    private PlayerShip player;
    private Fleet fleet;
    @Override
    public void create() {
        Gdx.graphics.setWindowedMode(600, 800);
        batch = new SpriteBatch();
        font = new BitmapFont(Gdx.files.internal("gamefont.fnt"),
                Gdx.files.internal("gamefont.png"), false);
        backgroundManagement = new BackgroundManagement(batch);
        font = new BitmapFont(Gdx.files.internal("gamefont.fnt"),
                Gdx.files.internal("gamefont.png"), false);
        //criar o player->
        player= new PlayerShip(batch,new Rectangle(300, 100,24,36));
        player.create();
        //fim de criar player <-

        //criar fleet ->
        fleet=new Fleet(batch);
        fleet.create();
        //fim de criar fleet <-
    }
    @Override
    public void render() {
        Gdx.gl.glClearColor(0, 0, 0.2f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        batch.begin();
        if (player.getLaser()!=null){
            fleet.handleCollisionsPtoS(player);
        }
        fleet.handleCollisionsStoP(player);

        backgroundManagement.render();
        font.draw(batch, "Life: "+player.getLife(), 460, 770);
        //player functions
        if (player.getLife()>0){
            player.render();
        }else{
            font.draw(batch, "YOU LOSE", 250, 400);
            System.out.println("YOU LOSE");
        }
        fleet.render(player);

        /*
        if(fleet.getFleetOfShips().size()==0){
            font.draw(batch, "YOU WIN", 250, 400);
        }

         */
        int x = 0;
        for (Ship ship:fleet.getFleetOfShips()) {
            if (ship.getShow()){
                x++;
            }
        }
        if (x==0){
            font.draw(batch, "YOU WIN", 250, 400);
        }
        batch.end();
    }
    @Override
    public void dispose() {
        batch.dispose();
    }
}