package pt.uma.arq.entities;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Timer;
import pt.uma.arq.game.Animator;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;


public class Fleet {
    private SpriteBatch batch;
    private ArrayList<Ship> fleetOfShips;
    //GET
    public ArrayList<Ship> getFleetOfShips() {
        return fleetOfShips;
    }
    Timer timer;

    /**
     * Construtor
     * @param batch
     */
    public Fleet(SpriteBatch batch){
        this.batch=batch;
        this.fleetOfShips=new ArrayList<Ship>();
        timer =new Timer();
        timer.scheduleTask(new Timer.Task() {
            @Override
            public void run() {
                shoot();
            }
        },1,2,-1);
    }

    /**
     * Create serve para a animação
     * Dá a posição inicial dos primeiros de cada tipo de nave inimiga.
     *
     * 8x -----------------------------------------
     * Cria uma instância do tipo de nave
     * Aplica metodo create()
     * Adiciona a nave ao ArrayList fleetOfShips
     * Atualiza a posição da proxima nave
     *---------------------------------------------
     *
     * Ordena por Damage utilizando o FleetComparatorByDamage()
     */
    public void create(){
        int xSmall=140,ySmall=500;
        int xMedium=50,yMedium=570;
        int xLarge=75,yLarge=640;
        for (int i = 0; i < 8; i++) {
            LargeShip largeShip = new LargeShip(batch,xLarge,yLarge,new Rectangle(xLarge,yLarge,0,0));
            largeShip.create();
            fleetOfShips.add(largeShip);
            MediumShip mediumShip = new MediumShip(batch,xMedium,yMedium,new Rectangle(xMedium,yMedium,0,0));
            mediumShip.create();
            fleetOfShips.add(mediumShip);
            SmallShip smallShip = new SmallShip(batch,xSmall,ySmall,new Rectangle(xSmall,ySmall,0,0));
            smallShip.create();
            fleetOfShips.add(smallShip);
            xSmall+=45;
            xMedium+=68;
            xLarge+=65;
        }
        Collections.sort(fleetOfShips, new FleetComparatorByDamage());
    }

    /**
     * Player atacks Ship
     * Faz a Ship show passar para false
     * Faz o laser do player passar para false
     * @param laser
     */
    public void handleCollisionsPtoS(PlayerShip player){
        Iterator<Ship> iterator=fleetOfShips.iterator();
        fleetOfShips.iterator();
        while (iterator.hasNext()){
            Ship ship = iterator.next();
            if(ship.getBoundingBox().intersects(player.getLaser().getBoundingBox())){
                System.out.println(fleetOfShips.size());
                ship.boundingBox.setBounds(0,0,0,0);
                player.getLaser().setShow(false);
                explosion(ship);
                iterator.remove();
            }
        }
        System.out.println(fleetOfShips.size());
    }

    /**
     * Player atacks Ship
     * Faz a Ship show passar para false
     * Faz o laser do player passar para false
     * @param player
     */
    public void handleCollisionsStoP(PlayerShip player){
        for (Ship ship:fleetOfShips) {
            if (ship.show){
                if (ship.getLaser()!=null){
                    if(ship.getLaser().getBoundingBox().intersects(player.getBoundingBox())){
                        ship.getLaser().setX(0);
                        ship.getLaser().setShow(false);
                        player.setLife(player.getLife()-ship.getDamage());
                       /* if (player.getLife()<=0){
                            System.out.println("YOU LOSEEEEEEEEEEEEEEEEEEEEEEEE");
                        }*/
                        System.out.println(player.getLife());
                    }
                }
            }
        }
    }

    public void render(PlayerShip player){
        int numOfEShips=0;
        for (Ship ship:fleetOfShips) {
            if (ship.show){
                ship.render();
                numOfEShips++;
            }
        }
        if (numOfEShips==0){
            //Ganhou
            System.out.println("Ganhou");
        }
    }

    /**
     * Seleciona um index random
     * Acedemos a esse index da fleetOfShips
     * Chama o shoot() dessa ship
     */
    public void shoot(){
        if (fleetOfShips.size()>0){

            int index = (int)(Math.random()*fleetOfShips.size());
            fleetOfShips.get(index).shoot();
        }
    }



    /**
     * Criação e animação da explosão
     * @param target é necessário para obtermos a posição da explusão
     */
    public void explosion(Ship target){
        Explosion explosion=new Explosion(batch,target.getX(),target.getY()-10);
        explosion.create();
        explosion.setShow(true);
        explosion.render();
        explosion.setShow(false);
    }
}
