package pt.uma.arq.entities;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import java.awt.*;
import java.util.*;

public class Fleet {
    private SpriteBatch batch;

    private PlayerShip player;
    private ArrayList<Ship> fleetOfShips;

    /**
     * Construtor
     * @param batch
     */
    public Fleet(SpriteBatch batch){
        this.batch=batch;
        this.fleetOfShips=new ArrayList<Ship>();
    }

    /**
     * obter o ArrayList fleetOfShips
     * @return
     */
    public ArrayList<Ship> getFleetOfShips() {
        return fleetOfShips;
    }
    /**
     * Dá a posição inicial dos primeiros de cada tipo de nave enemiga.
     * Cria uma instância do tipo de nave
     * Aplica metodo create()
     * Adiciona a nave ao ArrayList fleetOfShips
     *
     * Ordena por Damage
     */
    public void create(){
        int xSmall=200,ySmall=500;
        int xMedium=90,yMedium=570;
        int xLarge=120,yLarge=640;
        for (int i = 0; i < 8; i++) {
            LargeShip largeShip = new LargeShip(batch,xLarge,yLarge,new Rectangle(xLarge,yLarge,48,48));
            largeShip.create();
            fleetOfShips.add(largeShip);
            MediumShip mediumShip = new MediumShip(batch,xMedium,yMedium,new Rectangle(xMedium,yMedium,60,48));
            mediumShip.create();
            fleetOfShips.add(mediumShip);
            SmallShip smallShip = new SmallShip(batch,xSmall,ySmall,new Rectangle(xSmall,ySmall,40,48));
            smallShip.create();
            fleetOfShips.add(smallShip);
            xSmall+=30;
            xMedium+=58;
            xLarge+=48;
        }
        Collections.sort(fleetOfShips, new FleetComparatorByDamage());
    }

    /**
     * Função render esta constantemente a ser chamada. É o que as faz aparecer todos os frames
     * Percorre o ArrayList fleetOfShips.
     * Chama render das ships que tem show == true.
     *
     * FALTA UM TIMER
     * Chama a função shoot()
     */
    public void render(PlayerShip player){
        //Render Fleet
        //função para ver se saiu da tela laser
        for (Ship ships:fleetOfShips) {
            if (ships.show){
                ships.render();
            }
            colision(player,ships);
        }

        //de 2 em 2 segundos chama o this.shoot() !!!! NOT SURE IF TIMER IS HERE ON IN FUNCTION SHOOT() !!!!

        shoot();
    }
    /**
     * Seleciona um index random
     * Acedemos a esse index da fleetOfShips
     * Chama o shoot() dessa ship
     */
    public void shoot(){
            int index = (int)(Math.random()*fleetOfShips.size());
            System.out.println(index);
            fleetOfShips.get(index).shoot();
    }

    public void colision(PlayerShip player,Ship ship){
        this.player=player;
        if(player.getPlayerLaser()!=null) {
            if(ship.boundingBox.contains(player.getPlayerLaser().getBoundingBox())){
                ship.show = false;
                ship.boundingBox.setBounds(0,0,0,0);
                System.out.println("-------------------------colisao-----------------------");
                player.getPlayerLaser().setShowLaserPlayer(false);

            }
        }

    }


}
