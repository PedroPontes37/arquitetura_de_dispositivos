package pt.uma.arq.entities;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import pt.uma.arq.game.Animator;

import java.awt.*;

public class Laser {

    //Criar uma instancia do tipo Rectangle
    private Rectangle boundingBox;
    private SpriteBatch batch;
    private Animator animator;
    private boolean showLaserPlayer=true;
    private boolean showLaserEnemy=true;

    private int direction;
    public boolean getShowLaserPlayer(){return this.showLaserPlayer;}
    public boolean getShowLaserEnemy(){return this.showLaserEnemy;}

    public Rectangle getBoundingBox() {
        return boundingBox;
    }
    private int x, y=100;
    public int getY() {
        return y;
    }
    public int getX() {
        return x;
    }
    public void setY(int y) {
        this.y = y;
    }
    public void setX(int x) {
        this.x = x;
    }

    public void setShowLaserPlayer(boolean showLaserPlayer) {
        this.showLaserPlayer = showLaserPlayer;
    }

    /**
     * Construtor
     *
     * É passado o path pois este construtor vai criar lasers para o player e para os enemys
     *
     * @param batch
     * @param path
     * @param x
     * @param y
     */
    public Laser(SpriteBatch batch,String path, int x, int y,Rectangle boundingBox,int direction){
        this.x=x;
        this.y=y;
        this.batch=batch;
        this.animator=new Animator(batch,path,2,1);
        this.boundingBox=boundingBox;
        this.direction=direction;
    }
    public void create(){
        this.animator.create();
    }

    /**
     * Objetico: mostrar o laser (em cada frame)
     * Mudar o showLAserPlayer para falso IF (SAIR DA TELA, COLIDIR COM UMA SHIP ENEMY)
     * Apenas mostrará se showLAserPlayer == true
     */
    public void render(){
        if (this.direction>0){
            if (this.y>800 /* || COLISION WITH ENEMY SHIP */){
                showLaserPlayer=false;
            }
            if (showLaserPlayer){
                y+=direction;
                this.animator.render(this.x,this.y);
            }
        }else{
            if (this.y<0 /* || COLISION WITH PLAYER SHIP */){
                showLaserEnemy=false;
            }
            if (showLaserEnemy){
                y+=direction;
                this.animator.render(this.x,this.y);
            }
        }
    }

}

