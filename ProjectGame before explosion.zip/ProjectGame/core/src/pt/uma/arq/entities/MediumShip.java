package pt.uma.arq.entities;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import pt.uma.arq.game.Animator;

import java.awt.*;

public class MediumShip extends Ship{
    private SpriteBatch batch;
    private Laser mediumLaser;
    /**
     * Construtor
     * @param batch
     * passamos os pontos x e y para poderem ser criados nas posições pretendidas definidos na fleet
     * @param x
     * @param y
     */
    public MediumShip(SpriteBatch batch, int x, int y, Rectangle boundingBox){
        this.batch=batch;
        this.animator=new Animator(batch, "enemy-medium.png",2,1);
        this.x=x;
        this.y=y;
        this.damage=10;
        this.boundingBox=boundingBox;
    }
    /**
     * Vai mostrar o laser caso ele ja nao seja nulo
     * (Elemudara o seu valor no shoot() que será chamado por um  timer)
     */
    @Override
    public void render() {
        this.animator.render(this.x,this.y);
        if (mediumLaser!=null){
            mediumLaser.render();
        }
        /*
        System.out.println("BoundingBox mediumShipp");
        System.out.println(this.boundingBox.getX());
        System.out.println(this.boundingBox.getY());

         */
    }
    /**
     * Inicializar: Mudar o valor do laser(not null) - logo será renderizado
     * Evocar o create do Laser
     */
    @Override
    public void shoot() {
        //condiçoes para apenas poder disparar uma bala de cada vez
        if (mediumLaser!=null){
            if(!mediumLaser.getShowLaserEnemy()){
                mediumLaser = new Laser(batch,"laser-bolts-enemys.png",this.getX(),this.getY()-5, new Rectangle(),-5);
                this.mediumLaser.create();
                System.out.println("bang medium");
            }
        }else {
            mediumLaser = new Laser(batch,"laser-bolts-enemys.png",this.getX(),this.getY()-5,new Rectangle(),-5);
            this.mediumLaser.create();
            System.out.println("bang medium");
        }
    }
    @Override
    public String toString() {
        return "MediumShip";
    }
}
