package pt.uma.arq.entities;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import pt.uma.arq.game.Animator;

import java.awt.*;

public abstract class Ship {
    protected Animator animator;
    protected int x, y, damage;

    //Criar uma instancia do tipo Rectangle
    protected Rectangle boundingBox;
    protected boolean show = true;
    //GETs e SETs
    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }

    public Rectangle getBoundingBox() {
        return boundingBox;
    }

    public int getDamage() {
        return damage;
    }
    public boolean getShow() {
        return show;
    }
    public void setX(int x) {this.x = x;}

    public void setY(int y) {this.y = y;}

    public void setBoundingBox(Rectangle boundingBox) {
        this.boundingBox = boundingBox;
    }

    /**
     * Animator apenas serve para fazer as imagens irem alternando para gerar uma animação.
     * O create "ativa" o animator.
     */
    public void create(){
        this.animator.create();
    }
    public abstract void render();
    public abstract void shoot();
}
