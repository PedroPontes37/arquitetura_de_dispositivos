package pt.uma.arq.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import pt.uma.arq.game.Animator;

import java.awt.*;

public class PlayerShip extends Ship {
    private SpriteBatch batch;
    private int x=300, y=100;
    private Laser playerLaser;

    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }

    public Laser getPlayerLaser() {
        return playerLaser;
    }

    public void setY(int y) {
        this.y = y;
    }
    public void setX(int x) {
        this.x = x;
    }
    public PlayerShip(SpriteBatch batch,Rectangle boundingBox){
        this.batch = batch;
        this.animator=new Animator(batch, "ship.png",5,2);
        this.boundingBox=boundingBox;
    }
    public void actions(){
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            this.setX(this.getX() - 5);
            if (this.getX()<0){
                this.setX(0);
            }
        }
        else if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)){
            this.setX(this.getX() + 5);
            if(this.getX()>575){
                this.setX(575);
            }
        }
        //else if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)){
            //this.shoot();
       // }
    }
    @Override
    public void create() {
        super.create();
    }
    @Override
    public void render(){
        this.shoot();
        this.animator.render(this.x,this.y);
        this.actions();
        if (playerLaser!=null){
            playerLaser.render();
            playerLaser.getBoundingBox().setBounds(playerLaser.getX(),playerLaser.getY(),24,48);

            //Teste boundingBox laserplayer
            System.out.println("----------------------------------------------"+playerLaser.getY());
            System.out.println("BoundingBox tiro X: "+playerLaser.getBoundingBox().getX());
            System.out.println("BoundingBox tiro Y: "+playerLaser.getBoundingBox().getY());


        }
        this.boundingBox.setBounds(this.x,this.y,24,36);
        //Teste boundingBox player
        System.out.println("Player x: "  + this.x);
        System.out.println("BoundingBox: "+this.boundingBox.getX());


    }
    @Override
    public void shoot() {
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)){

    //condiçoes para apenas poder disparar uma bala de cada vez
    if (playerLaser!=null){
        if(!playerLaser.getShowLaserPlayer()){
            playerLaser = new Laser(batch, "laser-bolts.png",this.x, this.y+5,new Rectangle(this.x,this.y+5,24,48),5);
            this.playerLaser.create();
            System.out.println("BANG!");
        }
    }else {
        playerLaser = new Laser(batch, "laser-bolts.png",this.x, this.y+5,new Rectangle(this.x,this.y+5,24,48),5);
        this.playerLaser.create();
        System.out.println("BANG!");
        System.out.println("BoundingBox tiro X: "+playerLaser.getBoundingBox().getX());
        System.out.println("BoundingBox tiro Y: "+playerLaser.getBoundingBox().getY());
    }


}
    }
}
