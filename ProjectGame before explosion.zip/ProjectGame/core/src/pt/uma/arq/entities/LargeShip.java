package pt.uma.arq.entities;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import pt.uma.arq.game.Animator;

import java.awt.*;

public class LargeShip extends Ship{
    private SpriteBatch batch;
    private Laser largeLaser;

    /**
     * Construtor
     * @param batch
     * passamos os pontos x e y para poderem ser criados nas posições pretendidas definidos na fleet
     * @param x
     * @param y
     */
    public LargeShip(SpriteBatch batch, int x, int y, Rectangle boundingBox){
        this.batch=batch;
        this.animator=new Animator(batch, "enemy-big.png",2,1);
        this.x=x;
        this.y=y;
        this.damage=20;
        this.boundingBox=boundingBox;
    }

    /**
     * Vai mostrar o laser caso ele ja nao seja nulo
     * (Elemudara o seu valor no shoot() que será chamado por um  timer)
     */
    @Override
    public void render() {
        this.animator.render(this.x,this.y);
        if (largeLaser!=null){
            largeLaser.render();
        }
        /*
        System.out.println("BoundingBox largeShipp");
        System.out.println(this.boundingBox.getX());
        System.out.println(this.boundingBox.getY());

         */
    }

    /**
     * Inicializar: Mudar o valor do laser(not null) - logo será renderizado
     * Evocar o create do Laser
     */
    @Override
    public void shoot() {
        //condiçoes para apenas poder disparar uma bala de cada vez
        if (largeLaser!=null){
            if(!largeLaser.getShowLaserEnemy()){
                largeLaser = new Laser(batch,"laser-bolts-enemys.png",this.getX(),getY()-5,new Rectangle(),-2);
                this.largeLaser.create();
                System.out.println("bang grande");
            }
        }else {
            largeLaser = new Laser(batch,"laser-bolts-enemys.png",this.getX(),getY()-5,new Rectangle(),-2);
            this.largeLaser.create();
            System.out.println("bang grande");
        }
    }
    @Override
    public String toString() {
        return "LargeShip";
    }
}
