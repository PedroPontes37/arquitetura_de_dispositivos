package pt.uma.arq.entities;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import pt.uma.arq.game.Animator;

import java.awt.*;

public class SmallShip extends Ship{
    private SpriteBatch batch;
    private Laser smallLaser;
    /**
     * Construtor
     * @param batch
     * passamos os pontos x e y para poderem ser criados nas posições pretendidas definidos na fleet
     * @param x
     * @param y
     */
    public SmallShip(SpriteBatch batch,int x, int y, Rectangle boundingBox){
        this.batch=batch;
        this.animator=new Animator(batch, "enemy-small.png",2,1);
        this.x=x;
        this.y=y;
        this.damage=5;
        this.boundingBox=boundingBox;
    }
    /**
     * Vai mostrar o laser caso ele ja nao seja nulo
     * (Elemudara o seu valor no shoot() que será chamado por um  timer)
     */
    @Override
    public void render() {
        this.animator.render(this.x,this.y);
        if (smallLaser!=null){
            smallLaser.render();
        }
        /*
        System.out.println("BoundingBox smallShipp");
        System.out.println(this.boundingBox.getX());
        System.out.println(this.boundingBox.getY());

         */
    }
    /**
     * Inicializar: Mudar o valor do laser(not null) - logo será renderizado
     * Evocar o create do Laser
     */
    @Override
    public void shoot() {
        //condiçoes para apenas poder disparar uma bala de cada vez
        if (smallLaser!=null){
            if(!smallLaser.getShowLaserEnemy()){
                smallLaser=new Laser(batch,"laser-bolts-enemys.png",this.getX(),getY()-5,new Rectangle(),-8);
                this.smallLaser.create();
               // System.out.println("bang small");
            }
        }else {
            smallLaser=new Laser(batch,"laser-bolts-enemys.png",this.getX(),getY()-5,new Rectangle(),-8);
            this.smallLaser.create();
            //System.out.println("bang smalll");
        }
    }
    @Override
    public String toString() {
        return "SmallShip";
    }

}
